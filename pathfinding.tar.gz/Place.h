#pragma once
class Place{
    public:
    double x,y;
    Place(){
    } 
    Place(double _x,double _y){
        x = _x;
        y = _y;        
    }     
};