#pragma once

#define FPS 60
#define HEIGHT 1000
#define WIDTH 1000
#define SCALE 1

#define PI 3.1415926535898